<?php
session_start();
require_once '../config.php'; // Usa '..' para voltar um diretório

// Segurança e autenticação
if (!isset($_SESSION['client_id']) || !isset($_SESSION['client_type']) || $_SESSION['client_type'] !== 'professor') {
    header('Location: ../login.php?erro=acesso_negado');
    exit;
}

$id_professor_logado = $_SESSION['client_id'];
$nome_professor = $_SESSION['client_name'] ?? 'Professor(a)';
$acao = $_GET['acao'] ?? 'listar'; // Ação padrão: listar os cursos

$mensagem_feedback = '';
if (isset($_SESSION['mensagem_crud_curso'])) {
    $mensagem_feedback = $_SESSION['mensagem_crud_curso'];
    unset($_SESSION['mensagem_crud_curso']);
}

// --- LÓGICA PARA BUSCAR DADOS PARA A PÁGINA ---
$curso = null;
$meus_cursos = [];

if ($acao === 'listar') {
    try {
        $stmt = $pdo->prepare("SELECT id, titulo, preco, nivel, ativo FROM cursos WHERE id_instrutor = :id_instrutor ORDER BY titulo ASC");
        $stmt->execute([':id_instrutor' => $id_professor_logado]);
        $meus_cursos = $stmt->fetchAll();
    } catch (PDOException $e) {
        $mensagem_feedback = "<div class='p-4 mb-4 text-sm text-red-700 bg-red-100 rounded-lg'>Erro ao carregar seus cursos.</div>";
    }
} elseif ($acao === 'novo' || $acao === 'editar') {
    $curso = ['id' => null, 'titulo' => '', 'subtitulo' => '', 'preco' => '', 'nivel' => 'Iniciante', 'duracao_horas' => '', 'descricao_completa' => '', 'ativo' => true, 'url_imagem_capa' => '', 'video_promocional_url' => ''];
    if ($acao === 'editar' && isset($_GET['id_curso'])) {
        $id_curso_editar = filter_var($_GET['id_curso'], FILTER_VALIDATE_INT);
        $stmt_edit = $pdo->prepare("SELECT * FROM cursos WHERE id = :id AND id_instrutor = :id_instrutor");
        $stmt_edit->execute([':id' => $id_curso_editar, ':id_instrutor' => $id_professor_logado]);
        $curso_db = $stmt_edit->fetch();
        if ($curso_db) {
            $curso = $curso_db;
        } else {
            $_SESSION['mensagem_crud_curso'] = "<div class='p-4 mb-4 text-sm text-red-700 bg-red-100 rounded-lg'>Curso não encontrado ou não pertence a você.</div>";
            header('Location: gerenciar_cursos.php?acao=listar');
            exit;
        }
    }
}

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Cursos - ForensicX</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { font-family: 'Montserrat', sans-serif; }
        .gradient-bg { background: linear-gradient(135deg, #7e22ce 0%, #3b0764 100%); }
        .sidebar-link.active { background-color: #f3e8ff; color: #7e22ce; font-weight: 600; }
        .sidebar-link:hover { background-color: #f5f3ff; }
    </style>
</head>
<body class="bg-gray-100">
<div class="flex min-h-screen">
    <!-- Sidebar -->
    <aside class="w-64 bg-white shadow-lg hidden md:flex flex-col">
        <div class="p-6 border-b">
            <a href="../index.php" class="flex items-center space-x-2 text-purple-800">
                <i class="fas fa-fingerprint text-3xl"></i>
                <h1 class="text-2xl font-bold tracking-tight">Forensic<span class="text-purple-500">X</span></h1>
            </a>
            <p class="text-xs text-gray-500 mt-1">Painel do Instrutor</p>
        </div>
        <nav class="p-4 space-y-2 flex-1">
            <a href="../professor.php" class="sidebar-link flex items-center p-3 text-gray-700 rounded-lg"><i class="fas fa-tachometer-alt w-5 text-center mr-3"></i> Dashboard</a>
            <a href="gerenciar_cursos.php?acao=novo" class="sidebar-link flex items-center p-3 text-gray-700 rounded-lg <?php if($acao === 'novo') echo 'active'; ?>"><i class="fas fa-plus-circle w-5 text-center mr-3"></i> Novo Curso</a>
            <a href="gerenciar_cursos.php?acao=listar" class="sidebar-link flex items-center p-3 text-gray-700 rounded-lg <?php if($acao === 'listar') echo 'active'; ?>"><i class="fas fa-book-open w-5 text-center mr-3"></i> Meus Cursos</a>
            <a href="#" class="sidebar-link flex items-center p-3 text-gray-400 rounded-lg cursor-not-allowed"><i class="fas fa-users w-5 text-center mr-3"></i> Alunos</a>
        </nav>
        <div class="p-4 border-t">
            <a href="../account.php" class="sidebar-link flex items-center p-3 text-gray-700 rounded-lg"><i class="fas fa-cog w-5 text-center mr-3"></i> Minha Conta</a>
            <a href="../logout.php" class="sidebar-link flex items-center p-3 text-red-600 rounded-lg mt-2"><i class="fas fa-sign-out-alt w-5 text-center mr-3"></i> Sair</a>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="flex-1 p-6 md:p-8 overflow-y-auto">
        <header class="flex justify-between items-center mb-8">
            <h2 class="text-3xl font-bold text-gray-800">
                <?php 
                    if ($acao === 'novo') echo 'Cadastrar Novo Curso';
                    elseif ($acao === 'editar') echo 'Editar Curso';
                    else echo 'Meus Cursos';
                ?>
            </h2>
            <div class="flex items-center space-x-4">
                <span class="text-sm">Olá, <strong class="font-medium"><?php echo htmlspecialchars($nome_professor); ?></strong></span>
                <a href="../account.php"><img class="h-10 w-10 rounded-full object-cover border-2 border-purple-300" src="https://i.pravatar.cc/150?u=<?php echo $id_professor_logado; ?>" alt="Avatar"></a>
            </div>
        </header>

        <?php if ($mensagem_feedback) { echo $mensagem_feedback; } ?>

        <?php if ($acao === 'novo' || $acao === 'editar'): ?>
            <!-- FORMULÁRIO DE NOVO/EDITAR CURSO -->
            <div class="bg-white rounded-lg shadow-md overflow-hidden">
                <div class="gradient-bg px-6 py-4"><h3 class="text-xl font-semibold text-white">Preencha os detalhes do curso abaixo</h3></div>
                <form action="salvar_curso.php" method="POST" class="p-6">
                    <input type="hidden" name="id_curso" value="<?php echo htmlspecialchars($curso['id']); ?>">
                    
                    <div class="mb-8"><h4 class="text-lg font-medium text-purple-900 mb-4 flex items-center"><i class="fas fa-info-circle mr-2"></i> Informações Básicas</h4>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div><label for="titulo" class="block text-sm font-medium text-gray-700">Nome do Curso*</label><input type="text" name="titulo" id="titulo" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm" value="<?php echo htmlspecialchars($curso['titulo']); ?>" required></div>
                            <div><label for="subtitulo" class="block text-sm font-medium text-gray-700">Subtítulo</label><input type="text" name="subtitulo" id="subtitulo" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm" value="<?php echo htmlspecialchars($curso['subtitulo']); ?>"></div>
                            <div><label for="preco" class="block text-sm font-medium text-gray-700">Preço (R$)*</label><input type="text" name="preco" id="preco" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm" value="<?php echo htmlspecialchars($curso['preco']); ?>" placeholder="Ex: 299,90" required></div>
                            <div><label for="nivel" class="block text-sm font-medium text-gray-700">Nível*</label><select name="nivel" id="nivel" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm"><option value="Iniciante" <?php if($curso['nivel'] == 'Iniciante') echo 'selected'; ?>>Iniciante</option><option value="Intermediário" <?php if($curso['nivel'] == 'Intermediário') echo 'selected'; ?>>Intermediário</option><option value="Avançado" <?php if($curso['nivel'] == 'Avançado') echo 'selected'; ?>>Avançado</option></select></div>
                            <div><label for="duracao_horas" class="block text-sm font-medium text-gray-700">Duração (horas)*</label><input type="number" name="duracao_horas" id="duracao_horas" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm" value="<?php echo htmlspecialchars($curso['duracao_horas']); ?>" required></div>
                        </div>
                        <div class="mt-6"><label for="descricao_completa" class="block text-sm font-medium text-gray-700">Descrição*</label><textarea name="descricao_completa" id="descricao_completa" rows="4" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm" required><?php echo htmlspecialchars($curso['descricao_completa']); ?></textarea></div>
                        <div class="mt-6"><label class="flex items-center"><input type="checkbox" name="ativo" value="1" class="rounded h-4 w-4 text-purple-600" <?php echo ($curso['id'] === null || $curso['ativo']) ? 'checked' : ''; ?>><span class="ml-2 text-sm text-gray-600">Curso ativo (visível para alunos)</span></label></div>
                    </div>
                    <div class="mb-8"><h4 class="text-lg font-medium text-purple-900 mb-4 flex items-center"><i class="fas fa-images mr-2"></i> Mídia do Curso</h4>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div><label for="url_imagem_capa" class="block text-sm font-medium text-gray-700">URL da Imagem de Capa</label><input type="text" name="url_imagem_capa" id="url_imagem_capa" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm" value="<?php echo htmlspecialchars($curso['url_imagem_capa']); ?>" placeholder="Ex: ../imagens_cursos/meu_curso.jpg"></div>
                            <div><label for="video_promocional_url" class="block text-sm font-medium text-gray-700">URL do Vídeo Promocional</label><input type="url" name="video_promocional_url" id="video_promocional_url" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm" value="<?php echo htmlspecialchars($curso['video_promocional_url']); ?>" placeholder="https://youtube.com/embed/..."></div>
                        </div>
                    </div>
                    <div class="flex justify-end gap-3 pt-6 border-t"><button type="submit" class="px-6 py-3 gradient-bg text-white rounded-lg hover:opacity-90 transition flex items-center justify-center"><i class="fas fa-save mr-2"></i> Salvar Curso</button></div>
                </form>
            </div>
        
        <?php elseif ($acao === 'listar'): ?>
            <!-- LISTA DE CURSOS -->
            <div class="bg-white rounded-lg shadow-md">
                <div class="overflow-x-auto">
                    <table class="min-w-full leading-normal">
                        <thead><tr><th class="px-5 py-3 border-b-2 text-left text-xs font-semibold text-gray-600 uppercase">Título</th><th class="px-5 py-3 border-b-2 text-left text-xs font-semibold text-gray-600 uppercase">Preço</th><th class="px-5 py-3 border-b-2 text-left text-xs font-semibold text-gray-600 uppercase">Status</th><th class="px-5 py-3 border-b-2 text-left text-xs font-semibold text-gray-600 uppercase">Ações</th></tr></thead>
                        <tbody class="text-gray-700">
                            <?php if (empty($meus_cursos)): ?>
                                <tr><td colspan="4" class="text-center py-10 text-gray-500">Você ainda não cadastrou nenhum curso. <a href="?acao=novo" class="text-purple-600 font-semibold">Crie o seu primeiro!</a></td></tr>
                            <?php else: ?>
                                <?php foreach ($meus_cursos as $curso): ?>
                                    <tr class="border-b"><td class="px-5 py-4"><p class="font-medium"><?php echo htmlspecialchars($curso['titulo']); ?></p></td><td class="px-5 py-4">R$ <?php echo htmlspecialchars(number_format($curso['preco'], 2, ',', '.')); ?></td><td class="px-5 py-4"><span class="px-2 py-1 font-semibold leading-tight rounded-full text-xs <?php echo $curso['ativo'] ? 'text-green-700 bg-green-100' : 'text-red-700 bg-red-100'; ?>"><?php echo $curso['ativo'] ? 'Ativo' : 'Inativo'; ?></span></td><td class="px-5 py-4 text-sm"><a href="gerenciar_cursos.php?acao=editar&id_curso=<?php echo $curso['id']; ?>" class="text-indigo-600 hover:text-indigo-900 mr-4 font-medium">Editar</a><a href="apagar_curso.php?id_curso=<?php echo $curso['id']; ?>" onclick="return confirm('Tem certeza que deseja apagar este curso? Esta ação não pode ser desfeita.');" class="text-red-600 hover:text-red-900 font-medium">Apagar</a></td></tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>
    </main>
</div>
</body>
</html>
