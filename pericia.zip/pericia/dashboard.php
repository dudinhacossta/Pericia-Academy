<?php
$nome_professor = 'Prof. João Silva';

$stats = [
    'faturamento_total' => 8000.50,
    'total_alunos' => 42,
];

$dados_cursos_totais = [
    'total_cursos' => 14,
    'soma_total_preco' => 15750.80
];

$ultimas_inscricoes = [
    ['nome_aluno' => 'Maria Santos', 'nome_curso' => 'Análise Forense Digital', 'valor_total' => 450.00, 'data_pedido' => '2024-12-20'],
    ['nome_aluno' => 'Carlos Oliveira', 'nome_curso' => 'Perícia Criminal', 'valor_total' => 380.00, 'data_pedido' => '2024-12-18'],
    ['nome_aluno' => 'Ana Costa', 'nome_curso' => 'Investigação Digital', 'valor_total' => 520.00, 'data_pedido' => '2024-12-15'],
    ['nome_aluno' => 'Pedro Lima', 'nome_curso' => 'Forense Computacional', 'valor_total' => 600.00, 'data_pedido' => '2024-12-12'],
    ['nome_aluno' => 'Lucia Ferreira', 'nome_curso' => 'Cibersegurança Aplicada', 'valor_total' => 420.00, 'data_pedido' => '2024-12-10']
];

$dados_grafico = [
    'labels' => ['Jul/2024', 'Ago/2024', 'Set/2024', 'Out/2024', 'Nov/2024', 'Dez/2024'],
    'data' => [1200.50, 2150.80, 1890.30, 2450.60, 3200.40, 4863.40]
];
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Dashboard do Professor - ForensicX</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <style>
        body { font-family: 'Montserrat', sans-serif; background: #f3f4f6; margin: 0; }
        .card { background: white; border-radius: 16px; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08); }
        .gradient-bg { background: linear-gradient(135deg, #7e22ce 0%, #3b0764 100%); }
        .stat-card { padding: 20px; border-radius: 12px; background: white; display: flex; gap: 15px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05); }
        .stat-icon { font-size: 28px; width: 60px; height: 60px; display: flex; justify-content: center; align-items: center; border-radius: 12px; }
        .stat-title { font-size: 14px; color: #6b7280; }
        .stat-value { font-size: 24px; font-weight: 700; color: #1f2937; }
        .btn-add { background: #10b981; color: white; padding: 10px; border-radius: 8px; font-weight: 600; cursor: pointer; }
    </style>
</head>
<body>

<?php require_once 'header.php'; ?>

<main class="py-6 px-4 max-w-7xl mx-auto">
    <h1 class="text-3xl font-bold text-gray-800 mb-2">Dashboard do Instrutor</h1>
    <p class="text-gray-600 mb-6">Bem-vindo(a), <?= htmlspecialchars($nome_professor) ?>!</p>

    <!-- Formulário de Inscrição -->
    <div class="bg-indigo-50 p-6 rounded-lg mb-8 border-2 border-dashed border-purple-400">
        <h3 class="text-lg font-semibold text-gray-800 mb-4"><i class="fas fa-plus-circle mr-2"></i>Adicionar Nova Inscrição</h3>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div><label>Aluno</label><input type="text" id="nome_aluno" class="w-full p-2 rounded" placeholder="João Silva"></div>
            <div>
                <label>Curso</label>
                <select id="nome_curso" class="w-full p-2 rounded">
                    <option value="">Selecione</option>
                    <option>Análise Forense Digital</option>
                    <option>Perícia Criminal</option>
                    <option>Investigação Digital</option>
                    <option>Forense Computacional</option>
                    <option>Cibersegurança Aplicada</option>
                </select>
            </div>
            <div><label>Valor (R$)</label><input type="number" id="valor_curso" class="w-full p-2 rounded" step="0.01"></div>
            <div><label>&nbsp;</label><button class="btn-add w-full" onclick="adicionarInscricao()">Adicionar</button></div>
        </div>
    </div>

    <!-- Estatísticas -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
        <div class="stat-card"><div class="stat-icon bg-purple-100 text-purple-600"><i class="fas fa-coins"></i></div><div><div class="stat-title">FATURAMENTO TOTAL</div><div class="stat-value" id="faturamento-total">R$ <?= number_format($stats['faturamento_total'], 2, ',', '.') ?></div></div></div>
        <div class="stat-card"><div class="stat-icon bg-blue-100 text-blue-600"><i class="fas fa-users"></i></div><div><div class="stat-title">TOTAL DE ALUNOS</div><div class="stat-value" id="total-alunos"><?= $stats['total_alunos'] ?></div></div></div>
        <div class="stat-card"><div class="stat-icon bg-green-100 text-green-600"><i class="fas fa-book-open"></i></div><div><div class="stat-title">CURSOS ATIVOS</div><div class="stat-value"><?= $dados_cursos_totais['total_cursos'] ?></div></div></div>
        <div class="stat-card"><div class="stat-icon bg-yellow-100 text-yellow-600"><i class="fas fa-dollar-sign"></i></div><div><div class="stat-title">SOMA DOS PREÇOS</div><div class="stat-value">R$ <?= number_format($dados_cursos_totais['soma_total_preco'], 2, ',', '.') ?></div></div></div>
    </div>

    <!-- Gráficos e Inscrições -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <div class="lg:col-span-2 card p-5">
            <h3 class="text-lg font-semibold text-gray-800 mb-4">Faturamento nos Últimos 6 Meses</h3>
            <div class="relative h-64"><canvas id="graficoFaturamento"></canvas></div>
        </div>
        <div class="card p-5">
            <h3 class="text-lg font-semibold text-gray-800 mb-4">Últimas Inscrições</h3>
            <ul id="lista-inscricoes" class="space-y-4 max-h-64 overflow-y-auto">
                <?php foreach ($ultimas_inscricoes as $inscricao): ?>
                    <li>
                        <div class="flex justify-between">
                            <div>
                                <p class="font-semibold"><?= htmlspecialchars($inscricao['nome_aluno']) ?></p>
                                <p class="text-sm text-gray-500"><?= htmlspecialchars($inscricao['nome_curso']) ?></p>
                            </div>
                            <div class="text-right">
                                <span class="text-green-600 font-bold">+R$ <?= number_format($inscricao['valor_total'], 2, ',', '.') ?></span>
                                <p class="text-xs text-gray-400"><?= date('d/m/Y', strtotime($inscricao['data_pedido'])) ?></p>
                            </div>
                        </div>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
</main>

<?php require_once 'footer.php'; ?>

<script>
    let faturamentoAtual = <?= $stats['faturamento_total'] ?>;
    let totalAlunosAtual = <?= $stats['total_alunos'] ?>;
    let graficoFaturamento;

    document.addEventListener('DOMContentLoaded', function () {
        const ctx = document.getElementById('graficoFaturamento');
        graficoFaturamento = new Chart(ctx, {
            type: 'line',
            data: {
                labels: <?= json_encode($dados_grafico['labels']) ?>,
                datasets: [{
                    label: 'Faturamento (R$)',
                    data: <?= json_encode($dados_grafico['data']) ?>,
                    borderColor: '#7e22ce',
                    backgroundColor: 'rgba(126, 34, 206, 0.1)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                plugins: { legend: { display: false } },
                scales: {
                    y: { beginAtZero: true },
                    x: { grid: { display: false } }
                }
            }
        });
    });

    function adicionarInscricao() {
        const nome = document.getElementById('nome_aluno').value;
        const curso = document.getElementById('nome_curso').value;
        const valor = parseFloat(document.getElementById('valor_curso').value);

        if (!nome || !curso || isNaN(valor)) {
            alert('Preencha todos os campos corretamente.');
            return;
        }

        faturamentoAtual += valor;
        totalAlunosAtual++;

        document.getElementById('faturamento-total').textContent = 'R$ ' + faturamentoAtual.toLocaleString('pt-BR', { minimumFractionDigits: 2 });
        document.getElementById('total-alunos').textContent = totalAlunosAtual;

        const novaLi = document.createElement('li');
        const hoje = new Date().toLocaleDateString('pt-BR');

        novaLi.innerHTML = `
            <div class="flex justify-between">
                <div><p class="font-semibold">${nome}</p><p class="text-sm text-gray-500">${curso}</p></div>
                <div class="text-right"><span class="text-green-600 font-bold">+R$ ${valor.toFixed(2).replace('.', ',')}</span><p class="text-xs text-gray-400">${hoje}</p></div>
            </div>
        `;

        document.getElementById('lista-inscricoes').prepend(novaLi);
        document.getElementById('nome_aluno').value = '';
        document.getElementById('nome_curso').value = '';
        document.getElementById('valor_curso').value = '';

        const ultIndice = graficoFaturamento.data.datasets[0].data.length - 1;
        graficoFaturamento.data.datasets[0].data[ultIndice] += valor;
        graficoFaturamento.update();

        alert('Inscrição adicionada com sucesso!');
    }

    
</script>

</body>
</html>