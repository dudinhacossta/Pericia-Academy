<?php 
session_start();
require_once 'config.php';

if (!isset($_SESSION['client_id'])) {
    header('Location: login.php');
    exit;
}

$cli = $_SESSION['client_id'];

// Simulando valor total (você pode puxar do banco)
$stmt = $pdo->prepare("
  SELECT ci.id_item_carrinho, ci.id_produto, ci.quantidade,
         c.titulo, c.preco
  FROM carrinho_itens ci
  JOIN cursos c ON ci.id_produto = c.id
  WHERE ci.id_cliente = :cli
");
$stmt->execute([':cli' => $cli]);
$itens = $stmt->fetchAll();

if (empty($itens)) {
    $_SESSION['mensagem_carrinho'] = "Carrinho vazio.";
    header('Location: carrinho.php');
    exit;
}

$total = array_reduce($itens, fn($s, $i) => $s + $i['preco'] * $i['quantidade'], 0);
$codigoPix = 'CLI' . $cli . '_' . uniqid();
$qrcodeUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=' . urlencode("PIX|ID:$codigoPix|VALOR:$total");

// Processar pagamento com cartão
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tipo_pagamento']) && $_POST['tipo_pagamento'] === 'cartao') {
    // Simular processamento do pagamento
    sleep(2); // Simular tempo de processamento
    
    // Aqui você implementaria a lógica real de pagamento
    $pagamentoSucesso = true; // Simular pagamento bem-sucedido
    
    if ($pagamentoSucesso) {
        $_SESSION['msg_pagamento'] = "Pagamento com cartão aprovado! Seus cursos estão disponíveis.";
        header('Location: pagamento.php');
        exit;
    } else {
        $_SESSION['msg_pagamento'] = "Pagamento recusado. Verifique os dados do cartão.";
        header('Location: pagamento.php');
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pagamento | Minimal Purple</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .payment-tab.active {
            border-bottom: 3px solid #8b5cf6;
            color: #8b5cf6;
        }
        .card-input:focus {
            box-shadow: 0 0 0 2px #8b5cf6;
        }
        
        /* Nova imagem de fundo com porco cofrinho */
        body {
            background: url('https://img.lovepik.com/bg/20240105/piggy-bank-on-purple-3D-background-with-coins-and-money_2726221_wh860.jpg!/fw/860') no-repeat center center fixed;
            background-size: cover;
            min-height: 100vh;
            margin: 0;
            position: relative;
            overflow-x: hidden;
        }
        
        /* Overlay escuro com maior opacidade */
        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.75); /* Opacidade aumentada */
            z-index: -1;
        }
        
        /* Efeito de vidro fosco com mais opacidade */
        .glass-card {
            background: rgba(255, 255, 255, 0.95); /* Mais opaco */
            backdrop-filter: blur(15px); /* Blur aumentado */
            -webkit-backdrop-filter: blur(15px);
            border-radius: 20px;
            box-shadow: 0 12px 40px rgba(0, 0, 0, 0.3);
            border: 1px solid rgba(255, 255, 255, 0.3);
            overflow: hidden;
        }
        
        .glass-nav {
            background: rgba(76, 29, 149, 0.9); /* Roxo mais escuro */
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        .glass-footer {
            background: rgba(76, 29, 149, 0.9); /* Roxo mais escuro */
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            border-top: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        .pulse {
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0% { box-shadow: 0 0 0 0 rgba(139, 92, 246, 0.7); }
            70% { box-shadow: 0 0 0 10px rgba(139, 92, 246, 0); }
            100% { box-shadow: 0 0 0 0 rgba(139, 92, 246, 0); }
        }
        
        .fade-in {
            animation: fadeIn 0.7s ease-in;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        /* Melhorias para contraste */
        .payment-tab {
            transition: all 0.3s ease;
        }
        
        .payment-tab:hover {
            background-color: rgba(139, 92, 246, 0.1);
        }
        
        input, .bg-purple-50 {
            border: 1px solid rgba(139, 92, 246, 0.3);
        }
        
        /* Overlay de processamento */
        .processing-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.7);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }
        
        .processing-card {
            background: white;
            padding: 30px;
            border-radius: 15px;
            text-align: center;
            max-width: 350px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        
        .spinner {
            width: 50px;
            height: 50px;
            border: 5px solid rgba(139, 92, 246, 0.2);
            border-top: 5px solid #8b5cf6;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin: 0 auto 20px;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        /* Confete refinado */
        .confetti {
            position: fixed;
            width: 10px;
            height: 10px;
            opacity: 0.7;
            animation: confettiFall 5s linear forwards;
            z-index: 2000;
            pointer-events: none;
        }
        
        @keyframes confettiFall {
            0% { transform: translateY(-100vh) rotate(0deg); opacity: 1; }
            70% { opacity: 0.7; }
            100% { transform: translateY(100vh) rotate(360deg); opacity: 0; }
        }
    </style>
</head>
<body class="min-h-screen flex flex-col">
    <!-- Navbar -->
    <nav class="glass-nav text-white p-4 shadow-md">
        <div class="container mx-auto flex justify-between items-center">
            <h1 class="text-xl font-bold flex items-center">
                <i class="fas fa-piggy-bank mr-2"></i> SecurePay
            </h1>
            <div class="flex space-x-4">
                <a href="#" class="hover:text-purple-200"><i class="fas fa-home"></i></a>
                <a href="#" class="hover:text-purple-200"><i class="fas fa-user"></i></a>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <main class="flex-grow flex items-center justify-center p-4">
        <div class="glass-card w-full max-w-md overflow-hidden my-8 fade-in">
            <!-- Header -->
            <div class="bg-gradient-to-r from-purple-700 to-purple-800 p-6 text-white">
                <h1 class="text-2xl font-bold flex items-center">
                    <i class="fas fa-wallet mr-3"></i> Finalizar Pagamento
                </h1>
                <p class="text-purple-100 mt-2 flex items-center">
                    <i class="fas fa-coins mr-2"></i> Total: <span class="font-bold ml-1">R$ <?= number_format($total, 2, ',', '.') ?></span>
                </p>
            </div>
            
            <!-- Tabs -->
            <div class="flex border-b border-purple-100">
                <button id="credit-tab" class="payment-tab active flex-1 py-4 font-medium">
                    <i class="fas fa-credit-card mr-2"></i> Cartão
                </button>
                <button id="pix-tab" class="payment-tab flex-1 py-4 font-medium text-gray-500">
                    <i class="fas fa-qrcode mr-2"></i> Pix
                </button>
            </div>
            
            <!-- Credit Card Form -->
            <div id="credit-form" class="p-6">
                <form id="credit-card-form" method="POST">
                    <input type="hidden" name="tipo_pagamento" value="cartao">
                    <input type="hidden" name="valor_total" value="<?= $total ?>">
                    
                    <div class="space-y-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">
                                <i class="fas fa-credit-card mr-1"></i> Número do Cartão
                            </label>
                            <div class="relative">
                                <input type="text" name="numero_cartao" class="w-full p-3 border border-gray-200 rounded-lg focus:outline-none focus:border-purple-500" placeholder="1234 5678 9012 3456" required>
                                <div class="absolute right-3 top-3 flex space-x-2">
                                    <i class="fab fa-cc-visa text-purple-600"></i>
                                    <i class="fab fa-cc-mastercard text-purple-600"></i>
                                </div>
                            </div>
                        </div>
                        
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">
                                    <i class="far fa-calendar mr-1"></i> Validade
                                </label>
                                <input type="text" name="validade" class="w-full p-3 border border-gray-200 rounded-lg focus:outline-none focus:border-purple-500" placeholder="MM/AA" required>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">
                                    <i class="fas fa-lock mr-1"></i> CVV
                                </label>
                                <input type="text" name="cvv" class="w-full p-3 border border-gray-200 rounded-lg focus:outline-none focus:border-purple-500" placeholder="123" required>
                            </div>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">
                                <i class="fas fa-user mr-1"></i> Nome no Cartão
                            </label>
                            <input type="text" name="nome_cartao" class="w-full p-3 border border-gray-200 rounded-lg focus:outline-none focus:border-purple-500" placeholder="Nome Completo" required>
                        </div>
                        
                        <div class="pt-4">
                            <button type="submit" class="w-full bg-gradient-to-r from-purple-700 to-purple-800 hover:from-purple-800 hover:to-purple-900 text-white py-3 rounded-lg font-medium transition flex items-center justify-center pulse">
                                <i class="fas fa-lock mr-2"></i> Pagar R$ <?= number_format($total, 2, ',', '.') ?>
                            </button>
                        </div>
                    </div>
                </form>
                
                <?php if (isset($_SESSION['msg_pagamento'])): ?>
                    <div class="mt-4">
                        <p class="text-green-700 font-medium flex items-center justify-center">
                            <i class="fas fa-check-circle mr-2"></i> <?= $_SESSION['msg_pagamento'] ?>
                        </p>
                        <?php unset($_SESSION['msg_pagamento']); ?>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- Pix Form -->
            <div id="pix-form" class="p-6 hidden">
                <div class="space-y-6 text-center">
                    <div class="bg-purple-50 p-6 rounded-lg border border-purple-100">
                        <div class="flex justify-center items-center mb-4">
                            <i class="fas fa-piggy-bank text-4xl text-purple-600 mr-3"></i>
                            <i class="fas fa-qrcode text-4xl text-purple-600"></i>
                        </div>
                        <p class="text-sm text-gray-600 mb-4">Escaneie o QR Code abaixo para realizar o pagamento</p>
                        <div class="bg-white p-4 rounded-lg inline-block border border-purple-100 shadow-sm">
                            <img src="<?= $qrcodeUrl ?>" alt="QR Code PIX" class="w-40 h-40 mx-auto">
                        </div>
                    </div>
                    
                    <div>
                        <p class="text-sm text-gray-600 mb-2 flex items-center justify-center">
                            <i class="fas fa-copy mr-1"></i> Ou copie o código abaixo:
                        </p>
                        <div class="bg-purple-50 p-3 rounded-lg flex justify-between items-center border border-purple-100">
                            <span class="text-sm font-mono text-purple-800" id="pix-code"><?= $codigoPix ?></span>
                            <button onclick="copyPix()" class="text-purple-600 hover:text-purple-800 transition">
                                <i class="far fa-copy"></i>
                            </button>
                        </div>
                    </div>
                    
                    <div class="pt-2">
                        <form method="POST" action="confirmar_pagamento.php">
                            <input type="hidden" name="valor_total" value="<?= $total ?>">
                            <input type="hidden" name="codigo_pix" value="<?= $codigoPix ?>">
                            <button type="submit" class="w-full bg-gradient-to-r from-purple-700 to-purple-800 hover:from-purple-800 hover:to-purple-900 text-white py-3 rounded-lg font-medium transition flex items-center justify-center">
                                <i class="fas fa-check-circle mr-2"></i> Já efetuei o pagamento de R$ <?= number_format($total, 2, ',', '.') ?>
                            </button>
                        </form>
                        <?php if (isset($_SESSION['msg_pagamento'])): ?>
                            <p class="text-green-700 mt-4 font-medium flex items-center justify-center">
                                <i class="fas fa-check-circle mr-2"></i> <?= $_SESSION['msg_pagamento'] ?>
                            </p>
                            <?php unset($_SESSION['msg_pagamento']); ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Overlay de processamento -->
    <div id="processing-overlay" class="processing-overlay hidden">
        <div class="processing-card">
            <div class="spinner"></div>
            <h2 class="text-xl font-bold text-purple-700 mb-2">Processando pagamento</h2>
            <p class="text-gray-600">Aguarde enquanto processamos sua transação...</p>
        </div>
    </div>

    <!-- Footer -->
    <footer class="glass-footer text-white p-4 text-center text-sm">
        <p>© 2025 SecurePay - Pagamentos Seguros</p>
        <div class="mt-2 flex justify-center space-x-4">
            <i class="fab fa-cc-visa"></i>
            <i class="fab fa-cc-mastercard"></i>
            <i class="fab fa-cc-amex"></i>
            <i class="fab fa-cc-paypal"></i>
        </div>
    </footer>

    <script>
        // Tab switching
        const creditTab = document.getElementById('credit-tab');
        const pixTab = document.getElementById('pix-tab');
        const creditForm = document.getElementById('credit-form');
        const pixForm = document.getElementById('pix-form');
        
        creditTab.addEventListener('click', () => {
            creditTab.classList.add('active');
            creditTab.classList.remove('text-gray-500');
            pixTab.classList.remove('active');
            pixTab.classList.add('text-gray-500');
            creditForm.classList.remove('hidden');
            pixForm.classList.add('hidden');
        });
        
        pixTab.addEventListener('click', () => {
            pixTab.classList.add('active');
            pixTab.classList.remove('text-gray-500');
            creditTab.classList.remove('active');
            creditTab.classList.add('text-gray-500');
            pixForm.classList.remove('hidden');
            creditForm.classList.add('hidden');
        });

        // Formata número do cartão
        const cardInput = document.querySelector('input[name="numero_cartao"]');
        cardInput.addEventListener('input', (e) => {
            let value = e.target.value.replace(/\s+/g, '').replace(/[^0-9]/g, '');
            if (value.length > 0) {
                value = value.match(new RegExp('.{1,4}', 'g')).join(' ');
            }
            e.target.value = value;
        });

        // Copiar código PIX
        function copyPix() {
            const text = document.getElementById('pix-code').innerText;
            navigator.clipboard.writeText(text).then(() => {
                // Criar elemento de feedback
                const feedback = document.createElement('div');
                feedback.innerHTML = '<i class="fas fa-check-circle mr-1"></i> Código copiado!';
                feedback.className = 'fixed bottom-4 right-4 bg-green-600 text-white px-4 py-2 rounded-lg shadow-lg flex items-center animate-fadeInOut';
                document.body.appendChild(feedback);
                
                // Remover após 2 segundos
                setTimeout(() => {
                    feedback.remove();
                }, 2000);
            });
        }
        
        // Adicionar animação fadeInOut
        const style = document.createElement('style');
        style.innerHTML = `
            @keyframes fadeInOut {
                0% { opacity: 0; transform: translateY(10px); }
                10% { opacity: 1; transform: translateY(0); }
                90% { opacity: 1; transform: translateY(0); }
                100% { opacity: 0; transform: translateY(10px); }
            }
            
            .animate-fadeInOut {
                animation: fadeInOut 2s ease forwards;
            }
        `;
        document.head.appendChild(style);
        
        // Processar pagamento com cartão
        document.getElementById('credit-card-form').addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Mostrar overlay de processamento
            document.getElementById('processing-overlay').classList.remove('hidden');
            
            // Simular processamento do pagamento
            setTimeout(() => {
                // Enviar formulário
                this.submit();
            }, 2000);
        });
        
        // Animação de confete (opcional - remova se preferir)
        function createConfetti() {
            const colors = ['#8b5cf6', '#6366f1', '#ec4899', '#f43f5e', '#10b981', '#0ea5e9'];
            const container = document.body;
            
            for (let i = 0; i < 100; i++) {
                const confetti = document.createElement('div');
                confetti.className = 'confetti';
                confetti.style.left = Math.random() * 100 + 'vw';
                confetti.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
                confetti.style.animationDelay = Math.random() * 5 + 's';
                confetti.style.width = Math.random() * 10 + 5 + 'px';
                confetti.style.height = Math.random() * 10 + 5 + 'px';
                
                container.appendChild(confetti);
                
                // Remover após animação
                setTimeout(() => {
                    if (confetti.parentNode) {
                        confetti.parentNode.removeChild(confetti);
                    }
                }, 5000);
            }
        }
        
        // Ativar confete apenas após pagamento bem-sucedido
        <?php if (isset($_SESSION['msg_pagamento']) && strpos($_SESSION['msg_pagamento'], 'aprovado') !== false): ?>
            window.addEventListener('load', createConfetti);
        <?php endif; ?>
    </script>
</body>
</html>