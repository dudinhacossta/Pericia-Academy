<?php
require 'config.php';
session_start();

// Definir dados do usuário (simulação)
if (!isset($_SESSION['user_name'])) {
    $_SESSION['user_name'] = 'Carlos Silva';
    $_SESSION['user_email'] = 'carlos.silva@email.com';
}

// Gerar token CSRF
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verificar token CSRF
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $errors[] = 'Token de segurança inválido.';
    } else {
        // Captura e sanitiza dados
        $titulo            = trim($_POST['titulo'] ?? '');
        $subtitulo         = trim($_POST['subtitulo'] ?? null);
        $descricao         = trim($_POST['descricao_completa'] ?? null);
        $instrutor         = trim($_POST['instrutor'] ?? '');
        $preco             = filter_var($_POST['preco'] ?? 0, FILTER_VALIDATE_FLOAT);
        $nivel             = trim($_POST['nivel'] ?? 'Iniciante');
        $duracaoHoras      = filter_var($_POST['duracao_horas'] ?? null, FILTER_VALIDATE_INT);
        $ativo             = isset($_POST['ativo']) ? 1 : 0;
        $urlImagemCapa     = null; // Inicializa como null

        // Validações
        if (!$titulo) {
            $errors[] = 'O campo Título é obrigatório.';
        }
        if (!$instrutor) {
            $errors[] = 'O campo Instrutor é obrigatório.';
        }
        if ($preco === false || $preco < 0) {
            $errors[] = 'Preço inválido.';
        }
        if ($duracaoHoras === false || $duracaoHoras < 0) {
            $errors[] = 'Duração inválida.';
        }

        // Processar upload da imagem, se enviada
        if (isset($_FILES['url_imagem_capa']) && $_FILES['url_imagem_capa']['error'] === UPLOAD_ERR_OK) {
            $file = $_FILES['url_imagem_capa'];
            
            // Verificar tipo de arquivo
            $allowedTypes = [
                'image/jpeg' => 'jpg',
                'image/png' => 'png',
                'image/gif' => 'gif'
            ];
            $fileType = $file['type'];
            if (!array_key_exists($fileType, $allowedTypes)) {
                $errors[] = 'Formato de arquivo inválido. Use apenas JPG, PNG ou GIF.';
            }
            
            // Verificar tamanho do arquivo (5MB)
            $maxSize = 5 * 1024 * 1024;
            if ($file['size'] > $maxSize) {
                $errors[] = 'O arquivo é muito grande. O tamanho máximo permitido é 5MB.';
            }
            
            if (empty($errors)) {
                $uploadDir = 'uploads/';
                if (!is_dir($uploadDir)) {
                    mkdir($uploadDir, 0755, true);
                }
                
                $ext = $allowedTypes[$fileType];
                $filename = uniqid('capa_', true) . '.' . $ext;
                $destination = $uploadDir . $filename;
                
                if (move_uploaded_file($file['tmp_name'], $destination)) {
                    $urlImagemCapa = $destination;
                } else {
                    $errors[] = 'Falha ao fazer upload da imagem.';
                }
            }
        }

        if (empty($errors)) {
            // Prepara e executa a inserção
            $sql = "INSERT INTO cursos
                (titulo, subtitulo, descricao_completa, instrutor, preco, url_imagem_capa, nivel, duracao_horas, ativo)
                VALUES
                (:titulo, :subtitulo, :descricao, :instrutor, :preco, :urlImagemCapa, :nivel, :duracaoHoras, :ativo)";

            $stmt = $pdo->prepare($sql);
            try {
                $stmt->execute([
                    ':titulo'          => $titulo,
                    ':subtitulo'       => $subtitulo,
                    ':descricao'       => $descricao,
                    ':instrutor'       => $instrutor,
                    ':preco'           => $preco,
                    ':urlImagemCapa'   => $urlImagemCapa,
                    ':nivel'           => $nivel,
                    ':duracaoHoras'    => $duracaoHoras,
                    ':ativo'           => $ativo,
                ]);
                
                $success = true;
                $_SESSION['success_message'] = 'Curso cadastrado com sucesso!';
                header('Location: professor.php?status=success');
                exit;
            } catch (PDOException $e) {
                $errors[] = 'Erro ao cadastrar curso: ' . $e->getMessage();
            }
        }
    }
}
// Exibir mensagem de sucesso se existir
if (isset($_SESSION['success_message'])) {
    $success_message = $_SESSION['success_message'];
    unset($_SESSION['success_message']);
}
?>
    
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Cursos | Investigação Digital</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Estilos mantidos da versão original */
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f5f3ff;
        }
        
        .gradient-bg {
            background: linear-gradient(135deg, #7e22ce 0%, #3b0764 100%);
        }
        
        .input-focus:focus {
            border-color: #9333ea;
            box-shadow: 0 0 0 3px rgba(147, 51, 234, 0.3);
        }
        
        .animate-pulse-slow {
            animation: pulse 4s cubic-bezier(0.4, 0, 0.6, 1) infinite;
        }
        
        @keyframes pulse {
            0%, 100% {
                opacity: 1;
            }
            50% {
                opacity: 0.8;
            }
        }
        
        .floating-label {
            position: absolute;
            top: 0;
            left: 0;
            transform: translate(12px, 12px);
            transition: all 0.2s ease-out;
            pointer-events: none;
            color: #9ca3af;
            background-color: white;
            padding: 0 4px;
            border-radius: 4px;
        }
        
        .floating-input:focus + .floating-label,
        .floating-input:not(:placeholder-shown) + .floating-label {
            transform: translate(12px, -8px) scale(0.85);
            color: #9333ea;
            background-color: white;
        }
        
        /* Estilos para dropdown */
        .dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            min-width: 200px;
            background-color: white;
            border-radius: 0.5rem;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            z-index: 50;
            margin-top: 0.5rem;
        }
        
        .dropdown:hover .dropdown-content {
            display: block;
        }
        
        .dropdown-item {
            padding: 0.75rem 1rem;
            display: flex;
            align-items: center;
            color: #4b5563;
            transition: all 0.2s;
        }
        
        .dropdown-item:hover {
            background-color: #f9fafb;
            color: #7e22ce;
        }
        
        .dropdown-divider {
            height: 1px;
            background-color: #e5e7eb;
            margin: 0.25rem 0;
        }
    </style>
</head>
<body class="min-h-screen">
    <!-- Header -->
    <header class="gradient-bg text-white shadow-lg">
        <div class="container mx-auto px-4 py-6">
            <div class="flex justify-between items-center">
                <div class="flex items-center space-x-2">
                    <i class="fas fa-fingerprint text-3xl"></i>
                    <h1 class="text-2xl font-bold">Forensic<span class="text-purple-300">X</span></h1>
                </div>
                <nav class="hidden md:flex space-x-6">
                    <a href="#" class="hover:text-purple-200 transition">Dashboard</a>
                    <a href="#" class="hover:text-purple-200 transition">Cursos</a>
                    <a href="#" class="hover:text-purple-200 transition">Alunos</a>
                    <a href="#" class="hover:text-purple-200 transition">Configurações</a>
                </nav>
                <div class="flex items-center space-x-4">
                    <button class="md:hidden text-xl">
                        <i class="fas fa-bars"></i>
                    </button>
                    
                    <!-- Dropdown do perfil -->
                    <div class="relative dropdown">
                        <button class="flex items-center focus:outline-none">
                            <div class="relative">
                                <img src="https://randomuser.me/api/portraits/men/32.jpg" alt="Perfil" class="w-10 h-10 rounded-full border-2 border-purple-300 cursor-pointer">
                                <span class="absolute top-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></span>
                            </div>
                        </button>
                        
                        <div class="dropdown-content">
                            <div class="px-4 py-3">
                                <p class="text-sm font-semibold text-gray-900"><?php echo htmlspecialchars($_SESSION['user_name']); ?></p>
                                <p class="text-xs text-gray-500 truncate"><?php echo htmlspecialchars($_SESSION['user_email']); ?></p>
                            </div>
                            <div class="dropdown-divider"></div>
                            <a href="#" class="dropdown-item">
                                <i class="fas fa-user-circle mr-2"></i> Meu Perfil
                            </a>
                            <a href="#" class="dropdown-item">
                                <i class="fas fa-cog mr-2"></i> Configurações
                            </a>
                            <div class="dropdown-divider"></div>
                            <a href="logout.php" class="dropdown-item text-red-500 hover:text-red-700">
                                <i class="fas fa-sign-out-alt mr-2"></i> Sair
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <main class="container mx-auto px-4 py-8">
        <div class="flex flex-col md:flex-row gap-8">
            <!-- Sidebar -->
            <aside class="w-full md:w-64 bg-white rounded-lg shadow-md p-6 h-fit">
                <h2 class="text-xl font-semibold text-purple-900 mb-6">Painel do Professor</h2>
                <ul class="space-y-3">
                    <li>
                        <a href="#" class="flex items-center space-x-3 p-2 rounded-lg bg-purple-100 text-purple-800">
                            <i class="fas fa-plus-circle w-5 text-center"></i>
                            <span>Novo Curso</span>
                        </a>
                    </li>
                    <li>
                        <a href="MeusCursosProfessor.php" class="flex items-center space-x-3 p-2 rounded-lg hover:bg-purple-50 text-gray-700 hover:text-purple-800 transition">
                            <i class="fas fa-book w-5 text-center"></i>
                            <span>Meus Cursos</span>
                        </a>
                    </li>

                    <li>
                        <a href="dashboard.php" class="flex items-center space-x-3 p-2 rounded-lg hover:bg-purple-50 text-gray-700 hover:text-purple-800 transition">
                            <i class="fas fa-chart-line w-5 text-center"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="configurações.php" class="flex items-center space-x-3 p-2 rounded-lg hover:bg-purple-50 text-gray-700 hover:text-purple-800 transition">
                            <i class="fas fa-cog w-5 text-center"></i>
                            <span>Configurações</span>
                        </a>
                    </li>
                </ul>
                
                <div class="mt-8 pt-6 border-t border-gray-200">
                    <div class="flex items-center space-x-3">
                        <div class="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center">
                            <i class="fas fa-question-circle text-purple-600"></i>
                        </div>
                        <div>
                            <h4 class="font-medium text-gray-800">Precisa de ajuda?</h4>
                            <a href="#" class="text-sm text-purple-600 hover:underline">Central de Ajuda</a>
                        </div>
                    </div>
                </div>
            </aside>

            <!-- Form Section -->
            <section class="flex-1">
                <div class="bg-white rounded-lg shadow-md overflow-hidden">
                    <div class="gradient-bg px-6 py-4">
                        <h2 class="text-xl font-semibold text-white">Cadastrar Novo Curso</h2>
                        <p class="text-purple-200 text-sm">Preencha os detalhes do curso abaixo</p>
                    </div>
                    
                    <?php if (!empty($errors)): ?>
                        <div class="bg-red-50 border-l-4 border-red-500 p-4 mx-6 mt-4">
                            <div class="flex">
                                <div class="flex-shrink-0">
                                    <svg class="h-5 w-5 text-red-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                                        <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd" />
                                    </svg>
                                </div>
                                <div class="ml-3">
                                    <h3 class="text-sm leading-5 font-medium text-red-800">
                                        Ocorreram <?php echo count($errors); ?> erros
                                    </h3>
                                    <div class="mt-2 text-sm leading-5 text-red-700">
                                        <ul class="list-disc pl-5">
                                            <?php foreach ($errors as $error): ?>
                                                <li><?php echo htmlspecialchars($error); ?></li>
                                            <?php endforeach; ?>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (isset($_GET['status']) && $_GET['status'] === 'success'): ?>
                        <div class="bg-green-50 border-l-4 border-green-500 p-4 mx-6 mt-4">
                            <div class="flex">
                                <div class="flex-shrink-0">
                                    <svg class="h-5 w-5 text-green-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                                        <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" />
                                    </svg>
                                </div>
                                <div class="ml-3">
                                    <p class="text-sm leading-5 text-green-700">
                                        <strong>Sucesso!</strong> Curso cadastrado com sucesso.
                                    </p>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <form id="courseForm" method="POST" class="p-6" enctype="multipart/form-data">
                        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                        
                        <!-- Course Basic Info -->
                        <div class="mb-8">
                            <h3 class="text-lg font-medium text-purple-900 mb-4 flex items-center">
                                <i class="fas fa-info-circle mr-2"></i> Informações Básicas
                            </h3>
                            
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <!-- Course Name -->
                                <div class="relative">
                                    <input type="text" id="titulo" name="titulo" class="floating-input w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none input-focus" placeholder=" " required value="<?php echo htmlspecialchars($_POST['titulo'] ?? ''); ?>">
                                    <label for="titulo" class="floating-label">Nome do Curso*</label>
                                </div>
                                
                                <!-- Subtitle -->
                                <div class="relative">
                                    <input type="text" id="subtitulo" name="subtitulo" class="floating-input w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none input-focus" placeholder=" " value="<?php echo htmlspecialchars($_POST['subtitulo'] ?? ''); ?>">
                                    <label for="subtitulo" class="floating-label">Subtítulo</label>
                                </div>
                                
                                <!-- Instructor -->
                                <div class="relative">
                                    <input type="text" id="instrutor" name="instrutor" class="floating-input w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none input-focus" placeholder=" " required value="<?php echo htmlspecialchars($_POST['instrutor'] ?? ''); ?>">
                                    <label for="instrutor" class="floating-label">Instrutor*</label>
                                </div>
                                
                                <!-- Price -->
                                <div class="relative">
                                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                        <span class="text-gray-500">R$</span>
                                    </div>
                                    <input type="number" id="preco" name="preco" class="floating-input w-full pl-8 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none input-focus" placeholder=" " min="0" step="0.01" value="<?php echo htmlspecialchars($_POST['preco'] ?? ''); ?>">
                                    <label for="preco" class="floating-label">Preço do Curso</label>
                                </div>
                                
                                <!-- Difficulty Level -->
                                <div class="relative">
                                    <select id="nivel" name="nivel" class="floating-input w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none input-focus appearance-none" required>
                                        <option value="" disabled>Selecione...</option>
                                        <option value="Iniciante" <?php echo (isset($_POST['nivel']) && $_POST['nivel'] === 'Iniciante') ? 'selected' : ''; ?>>Iniciante</option>
                                        <option value="Intermediário" <?php echo (isset($_POST['nivel']) && $_POST['nivel'] === 'Intermediário') ? 'selected' : ''; ?>>Intermediário</option>
                                        <option value="Avançado" <?php echo (isset($_POST['nivel']) && $_POST['nivel'] === 'Avançado') ? 'selected' : ''; ?>>Avançado</option>
                                        <option value="Especialista" <?php echo (isset($_POST['nivel']) && $_POST['nivel'] === 'Especialista') ? 'selected' : ''; ?>>Especialista</option>
                                    </select>
                                    <label for="nivel" class="floating-label">Nível de Dificuldade*</label>
                                    <i class="fas fa-chevron-down absolute right-3 top-4 text-gray-400 pointer-events-none"></i>
                                </div>
                                
                                <!-- Duration -->
                                <div class="relative">
                                    <input type="number" id="duracao_horas" name="duracao_horas" class="floating-input w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none input-focus" placeholder=" " min="0" value="<?php echo htmlspecialchars($_POST['duracao_horas'] ?? ''); ?>">
                                    <label for="duracao_horas" class="floating-label">Duração (horas)*</label>
                                </div>
                            </div>
                            
                            <!-- Description -->
                            <div class="mt-6">
                                <label for="descricao_completa" class="block text-sm font-medium text-gray-700 mb-2">Descrição do Curso*</label>
                                <textarea id="descricao_completa" name="descricao_completa" rows="4" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none input-focus" placeholder="Descreva o conteúdo do curso, objetivos e público-alvo..." required><?php echo htmlspecialchars($_POST['descricao_completa'] ?? ''); ?></textarea>
                            </div>
                            
                            <!-- Active Status -->
                            <div class="mt-4">
                                <label class="inline-flex items-center">
                                    <input type="checkbox" name="ativo" class="form-checkbox h-5 w-5 text-purple-600 rounded focus:ring-purple-500 border-gray-300" <?php echo (isset($_POST['ativo']) && $_POST['ativo']) ? 'checked' : 'checked'; ?>>
                                    <span class="ml-2 text-gray-700">Curso ativo</span>
                                </label>
                            </div>
                        </div>
                        
                        <!-- Course Media -->
                        <div class="mb-8">
                            <h3 class="text-lg font-medium text-purple-900 mb-4 flex items-center">
                                <i class="fas fa-images mr-2"></i> Mídia do Curso
                            </h3>
                            
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <!-- Thumbnail Upload -->
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Thumbnail do Curso</label>
                                    <div class="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-lg relative">
                                        <div class="space-y-1 text-center">
                                            <div class="flex justify-center text-gray-400">
                                                <i class="fas fa-image text-4xl"></i>
                                            </div>
                                            <div class="flex text-sm text-gray-600">
                                                <label for="url_imagem_capa" class="relative cursor-pointer bg-white rounded-md font-medium text-purple-600 hover:text-purple-500 focus-within:outline-none">
                                                    <span>Envie uma imagem</span>
                                                    <input id="url_imagem_capa" name="url_imagem_capa" type="file" class="absolute inset-0 w-full h-full opacity-0 cursor-pointer" accept="image/*">
                                                </label>
                                            </div>
                                            <p class="text-xs text-gray-500">PNG, JPG, GIF até 5MB</p>
                                        </div>
                                    </div>
                                    <!-- Área para mostrar o nome do arquivo -->
                                    <div id="file-info" class="mt-2 text-center text-sm text-gray-600"></div>
                                    <div id="image-preview" class="mt-2 text-center"></div>
                                </div>
                                
                                <!-- Promo Video -->
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Vídeo Promocional (URL)</label>
                                    <div class="mt-1">
                                        <input type="url" id="promo_video" name="promo_video" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none input-focus" placeholder="https://youtube.com/embed/..." value="<?php echo htmlspecialchars($_POST['promo_video'] ?? ''); ?>">
                                    </div>
                                    <p class="mt-1 text-xs text-gray-500">Cole o URL de incorporação do YouTube ou Vimeo</p>
                                </div>
                            </div>
                        </div>      
                        <!-- Form Actions -->
                        <div class="flex flex-col sm:flex-row justify-end gap-3 pt-6 border-t border-gray-200">
                            <button type="button" class="px-6 py-3 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition">
                                Cancelar
                            </button>
                            <button type="button" class="px-6 py-3 bg-purple-100 text-purple-700 rounded-lg hover:bg-purple-200 transition">
                                Salvar como Rascunho
                            </button>
                            <button type="submit" class="px-6 py-3 gradient-bg text-white rounded-lg hover:opacity-90 transition flex items-center justify-center">
                                <i class="fas fa-save mr-2"></i> Publicar Curso
                            </button>
                        </div>
                    </form>
                </div>
            </section>
        </div>
    </main>

    <script>
        // Module and Lesson Management
        let moduleCount = <?php echo isset($_POST['modulos']) ? count($_POST['modulos']) : 1; ?>;
        let lessonCounts = [<?php echo isset($_POST['modulos']) ? implode(',', array_map('count', $_POST['modulos'])) : 1; ?>];
        
        function addModule() {
            moduleCount++;
            lessonCounts.push(1); // Initialize lesson count for new module
            
            const modulesContainer = document.getElementById('modulesContainer');
            const newModule = document.createElement('div');
            newModule.className = 'module-item mb-6 p-4 border border-gray-200 rounded-lg';
            newModule.innerHTML = `
                <div class="flex justify-between items-center mb-3">
                    <h4 class="font-medium text-purple-800">Módulo ${moduleCount}</h4>
                    <button type="button" class="text-red-500 hover:text-red-700" onclick="removeModule(this)">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
                
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Título do Módulo*</label>
                    <input type="text" name="modulos[${moduleCount-1}][titulo]" class="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none input-focus" placeholder="Ex: Introdução à Forense Digital" required>
                </div>
                
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Descrição do Módulo</label>
                    <textarea name="modulos[${moduleCount-1}][descricao]" class="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none input-focus" rows="2" placeholder="Descreva o conteúdo deste módulo..."></textarea>
                </div>
                
                <div class="lessons-container ml-4 pl-4 border-l-2 border-purple-100">
                    <div class="lesson-item mb-4 p-3 bg-gray-50 rounded">
                        <div class="flex justify-between items-center mb-2">
                            <h5 class="text-sm font-medium text-gray-800">Aula 1</h5>
                            <button type="button" class="text-red-500 hover:text-red-700 text-sm" onclick="removeLesson(this)">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div>
                                <label class="block text-xs font-medium text-gray-600 mb-1">Título da Aula*</label>
                                <input type="text" name="modulos[${moduleCount-1}][aulas][0][titulo]" class="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:outline-none input-focus" placeholder="Ex: Conceitos Básicos" required>
                            </div>
                            <div>
                                <label class="block text-xs font-medium text-gray-600 mb-1">Tipo de Conteúdo*</label>
                                <select name="modulos[${moduleCount-1}][aulas][0][tipo]" class="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:outline-none input-focus" required>
                                    <option value="">Selecione...</option>
                                    <option value="video">Vídeo</option>
                                    <option value="text">Texto</option>
                                    <option value="quiz">Quiz</option>
                                    <option value="file">Arquivo</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="mt-2">
                            <label class="block text-xs font-medium text-gray-600 mb-1">Conteúdo/URL*</label>
                            <input type="text" name="modulos[${moduleCount-1}][aulas][0][conteudo]" class="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:outline-none input-focus" placeholder="URL do vídeo ou texto do conteúdo" required>
                        </div>
                    </div>
                </div>
                
                <button type="button" class="add-lesson-btn text-xs text-purple-600 hover:text-purple-800 flex items-center mt-2" onclick="addLesson(this)">
                    <i class="fas fa-plus-circle mr-1"></i> Adicionar Aula
                </button>
            `;
            
            modulesContainer.appendChild(newModule);
        }
        
        function removeModule(button) {
            if (moduleCount > 1) {
                const moduleItem = button.closest('.module-item');
                const moduleIndex = Array.from(moduleItem.parentNode.children).indexOf(moduleItem);
                
                moduleItem.remove();
                moduleCount--;
                lessonCounts.splice(moduleIndex, 1);
                
                // Update module numbers
                const modules = document.querySelectorAll('.module-item');
                modules.forEach((module, index) => {
                    module.querySelector('h4').textContent = `Módulo ${index + 1}`;
                    // Update input names
                    const inputs = module.querySelectorAll('input, select, textarea');
                    inputs.forEach(input => {
                        const name = input.getAttribute('name');
                        if (name) {
                            const newName = name.replace(/modulos\[\d+\]/g, `modulos[${index}]`);
                            input.setAttribute('name', newName);
                        }
                    });
                });
            } else {
                alert('O curso deve ter pelo menos um módulo.');
            }
        }
        
        function addLesson(button) {
            const moduleItem = button.closest('.module-item');
            const moduleIndex = Array.from(moduleItem.parentNode.children).indexOf(moduleItem);
            
            lessonCounts[moduleIndex]++;
            const lessonCount = lessonCounts[moduleIndex];
            
            const lessonsContainer = moduleItem.querySelector('.lessons-container');
            const newLesson = document.createElement('div');
            newLesson.className = 'lesson-item mb-4 p-3 bg-gray-50 rounded';
            newLesson.innerHTML = `
                <div class="flex justify-between items-center mb-2">
                    <h5 class="text-sm font-medium text-gray-800">Aula ${lessonCount}</h5>
                    <button type="button" class="text-red-500 hover:text-red-700 text-sm" onclick="removeLesson(this)">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div>
                        <label class="block text-xs font-medium text-gray-600 mb-1">Título da Aula*</label>
                        <input type="text" name="modulos[${moduleIndex}][aulas][${lessonCount-1}][titulo]" class="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:outline-none input-focus" placeholder="Ex: Conceitos Básicos" required>
                    </div>
                    <div>
                        <label class="block text-xs font-medium text-gray-600 mb-1">Tipo de Conteúdo*</label>
                        <select name="modulos[${moduleIndex}][aulas][${lessonCount-1}][tipo]" class="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:outline-none input-focus" required>
                            <option value="">Selecione...</option>
                            <option value="video">Vídeo</option>
                            <option value="text">Texto</option>
                            <option value="quiz">Quiz</option>
                            <option value="file">Arquivo</option>
                        </select>
                    </div>
                </div>
                
                <div class="mt-2">
                    <label class="block text-xs font-medium text-gray-600 mb-1">Conteúdo/URL*</label>
                    <input type="text" name="modulos[${moduleIndex}][aulas][${lessonCount-1}][conteudo]" class="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:outline-none input-focus" placeholder="URL do vídeo ou texto do conteúdo" required>
                </div>
            `;
            
            lessonsContainer.appendChild(newLesson);
        }
        
        function removeLesson(button) {
            const lessonItem = button.closest('.lesson-item');
            const lessonsContainer = lessonItem.parentNode;
            
            if (lessonsContainer.children.length > 1) {
                lessonItem.remove();
                
                // Update lesson numbers in this module
                const moduleItem = button.closest('.module-item');
                const moduleIndex = Array.from(moduleItem.parentNode.children).indexOf(moduleItem);
                lessonCounts[moduleIndex]--;
                
                const lessons = moduleItem.querySelectorAll('.lesson-item');
                lessons.forEach((lesson, index) => {
                    lesson.querySelector('h5').textContent = `Aula ${index + 1}`;
                    // Update input names
                    const inputs = lesson.querySelectorAll('input, select');
                    inputs.forEach(input => {
                        const name = input.getAttribute('name');
                        if (name) {
                            const newName = name.replace(/aulas\[\d+\]/g, `aulas[${index}]`);
                            input.setAttribute('name', newName);
                        }
                    });
                });
            } else {
                alert('Cada módulo deve ter pelo menos uma aula.');
            }
        }
        
        // Form Validation
        document.getElementById('courseForm').addEventListener('submit', function(e) {
            // Validate required fields
            const requiredFields = [
                document.getElementById('titulo'),
                document.getElementById('instrutor'),
                document.getElementById('nivel'),
                document.getElementById('descricao_completa')
            ];
            
            let isValid = true;
            
            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    isValid = false;
                    field.classList.add('border-red-500');
                    field.classList.remove('input-focus');
                } else {
                    field.classList.remove('border-red-500');
                    if (field.classList.contains('input-focus') || field.value) {
                        field.classList.add('input-focus');
                    }
                }
            });
            
            // Validate modules
            const modules = document.querySelectorAll('.module-item');
            modules.forEach(module => {
                const moduleTitle = module.querySelector('input[name$="[titulo]"]');
                if (!moduleTitle.value.trim()) {
                    isValid = false;
                    moduleTitle.classList.add('border-red-500');
                    moduleTitle.classList.remove('input-focus');
                } else {
                    moduleTitle.classList.remove('border-red-500');
                    if (moduleTitle.classList.contains('input-focus') || moduleTitle.value) {
                        moduleTitle.classList.add('input-focus');
                    }
                }
                
                // Validate lessons
                const lessons = module.querySelectorAll('.lesson-item');
                lessons.forEach(lesson => {
                    const lessonTitle = lesson.querySelector('input[name$="[titulo]"]');
                    const lessonType = lesson.querySelector('select[name$="[tipo]"]');
                    const lessonContent = lesson.querySelector('input[name$="[conteudo]"]');
                    
                    if (!lessonTitle.value.trim()) {
                        isValid = false;
                        lessonTitle.classList.add('border-red-500');
                    } else {
                        lessonTitle.classList.remove('border-red-500');
                    }
                    
                    if (!lessonType.value) {
                        isValid = false;
                        lessonType.classList.add('border-red-500');
                    } else {
                        lessonType.classList.remove('border-red-500');
                    }
                    
                    if (!lessonContent.value.trim()) {
                        isValid = false;
                        lessonContent.classList.add('border-red-500');
                    } else {
                        lessonContent.classList.remove('border-red-500');
                    }
                });
            });
            
            if (!isValid) {
                e.preventDefault();
                alert('Por favor, preencha todos os campos obrigatórios.');
            }
        });
        
        // Initialize floating labels
        document.querySelectorAll('.floating-input').forEach(input => {
            // Check if input has value on page load
            if (input.value) {
                input.nextElementSibling.classList.add('floating-label-active');
            }
            
            // Add event listeners
            input.addEventListener('focus', () => {
                input.nextElementSibling.classList.add('floating-label-active');
            });
            
            input.addEventListener('blur', () => {
                if (!input.value) {
                    input.nextElementSibling.classList.remove('floating-label-active');
                }
            });
        });
        
        // Preview da imagem de capa e exibição do nome do arquivo
        document.getElementById('url_imagem_capa').addEventListener('change', function(e) {
            const preview = document.getElementById('image-preview');
            const fileInfo = document.getElementById('file-info');
            preview.innerHTML = '';
            fileInfo.innerHTML = '';
            
            if (this.files && this.files[0]) {
                const file = this.files[0];
                
                // Mostrar informações do arquivo
                fileInfo.innerHTML = `
                    <div class="bg-gray-50 p-2 rounded-lg">
                        <div class="font-medium text-gray-800">Arquivo selecionado:</div>
                        <div class="flex items-center mt-1">
                            <i class="fas fa-file-image text-purple-600 mr-2"></i>
                            <span class="truncate">${file.name}</span>
                        </div>
                        <div class="text-xs text-gray-500 mt-1">
                            Tamanho: ${(file.size / 1024 / 1024).toFixed(2)} MB
                        </div>
                    </div>
                `;
                
                // Se for uma imagem, mostrar o preview
                if (file.type.match('image.*')) {
                    const reader = new FileReader();
                    
                    reader.onload = function(e) {
                        const img = document.createElement('img');
                        img.src = e.target.result;
                        img.className = 'max-h-32 mx-auto';
                        preview.appendChild(img);
                    }
                    
                    reader.readAsDataURL(file);
                }
            }
        });
        
        // Fechar dropdown quando clicar fora
        document.addEventListener('click', function(event) {
            const dropdowns = document.querySelectorAll('.dropdown');
            dropdowns.forEach(dropdown => {
                if (!dropdown.contains(event.target)) {
                    const content = dropdown.querySelector('.dropdown-content');
                    content.style.display = 'none';
                }
            });
        });
    </script>
    <?php include 'footer.php'; ?>
</body>
</html>