<?php
require_once 'config.php';

// Segurança: só professores
if (!isset($_SESSION['client_id']) || !isset($_SESSION['client_type']) || $_SESSION['client_type'] !== 'professor') {
    header('Location: login.php?erro=acesso_negado');
    exit;
}

$nome_professor = $_SESSION['client_name'] ?? 'Professor(a)';
?>

<header class="bg-purple-600 text-white shadow-md sticky top-0 z-50">
    <div class="container mx-auto px-4 py-6">
        <div class="flex items-center justify-between">
            <a href="index.php" class="text-2xl font-bold hover:text-purple-200">Perícia Academy</a>

            <!-- Desktop Menu -->
            <div class="hidden lg:flex lg:items-center lg:space-x-4">
                <a href="professor.php" class="hover:text-purple-200 px-3 py-2 rounded-md text-sm font-medium">Dashboard</a>
                <a href="meus_cursos.php" class="hover:text-purple-200 px-3 py-2 rounded-md text-sm font-medium">Cursos</a>
                <a href="account.php" class="hover:text-purple-200 px-3 py-2 rounded-md text-sm font-medium">Configurações</a>
                <span class="ml-4 text-sm italic">Bem-vindo, <?php echo htmlspecialchars($nome_professor); ?></span>
            </div>

            <!-- Botão Mobile -->
            <div class="lg:hidden">
                <button id="nav-toggle" class="text-white p-2 rounded-md hover:text-purple-200 hover:bg-purple-700 focus:outline-none">
                    <svg class="h-6 w-6" stroke="currentColor" fill="none" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
                    </svg>
                </button>
            </div>
        </div>
    </div>

    <!-- Menu Lateral Mobile -->
    <div id="nav-content-mobile" class="hidden lg:hidden fixed top-0 left-0 w-64 h-full bg-purple-700 shadow-lg z-50 transform -translate-x-full transition-transform duration-300 ease-in-out">
        <div class="p-5">
            <div class="flex justify-between items-center mb-6">
                <span class="text-xl font-bold text-white">Menu</span>
                <button id="nav-close-mobile" class="text-white p-2 rounded-md hover:bg-purple-800">
                    <svg class="h-6 w-6" stroke="currentColor" fill="none" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
            </div>
            <nav class="flex flex-col space-y-2">
                <a href="professor.php" class="block hover:bg-purple-800 text-white px-3 py-2 rounded-md text-base font-medium">Dashboard</a>
                <a href="meus_cursos.php" class="block hover:bg-purple-800 text-white px-3 py-2 rounded-md text-base font-medium">Cursos</a>
                <a href="account.php" class="block hover:bg-purple-800 text-white px-3 py-2 rounded-md text-base font-medium">Configurações</a>
            </nav>
        </div>
    </div>
    <div id="nav-overlay" class="hidden fixed inset-0 bg-black opacity-50 z-40 lg:hidden"></div>
</header>

<script>
    const navToggle = document.getElementById('nav-toggle');
    const navContentMobile = document.getElementById('nav-content-mobile');
    const navCloseMobile = document.getElementById('nav-close-mobile');
    const navOverlay = document.getElementById('nav-overlay');
    const mobileMenuLinks = navContentMobile.querySelectorAll('a');

    function openMobileMenu() {
        navContentMobile.classList.remove('hidden', '-translate-x-full');
        navContentMobile.classList.add('translate-x-0');
        navOverlay.classList.remove('hidden');
        document.body.classList.add('overflow-hidden');
    }

    function closeMobileMenu() {
        navContentMobile.classList.add('-translate-x-full');
        navContentMobile.classList.remove('translate-x-0');
        setTimeout(() => {
            navContentMobile.classList.add('hidden');
        }, 300);
        navOverlay.classList.add('hidden');
        document.body.classList.remove('overflow-hidden');
    }

    if (navToggle) navToggle.addEventListener('click', e => { e.stopPropagation(); openMobileMenu(); });
    if (navCloseMobile) navCloseMobile.addEventListener('click', closeMobileMenu);
    if (navOverlay) navOverlay.addEventListener('click', closeMobileMenu);
    mobileMenuLinks.forEach(link => {
        link.addEventListener('click', () => {
            if (link.getAttribute('href') && link.getAttribute('href') !== '#') closeMobileMenu();
        });
    });
</script>
