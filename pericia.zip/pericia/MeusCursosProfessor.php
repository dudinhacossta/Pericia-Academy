<?php
session_start();
require_once 'config.php';

// Segurança: só professores
if (!isset($_SESSION['client_id']) || !isset($_SESSION['client_type']) || $_SESSION['client_type'] !== 'professor') {
    header('Location: login.php?erro=acesso_negado');
    exit;
}

$nome_professor = $_SESSION['client_name'] ?? 'Professor(a)';
$mensagem_feedback = '';
$mostrar_form_edicao = false;
$curso_atual = null;

if (isset($_GET['acao'])) {
    $acao = $_GET['acao'];
    $id_curso = $_GET['id_curso'] ?? null;

    if ($acao === 'apagar' && $id_curso) {
        try {
            $stmt = $pdo->prepare("DELETE FROM cursos WHERE id = ?");
            $stmt->execute([$id_curso]);
            $_SESSION['mensagem_crud_curso'] = "<div class='p-4 mb-4 text-sm text-green-700 bg-green-100 rounded-lg'>Curso apagado com sucesso.</div>";
            header('Location: ' . basename(__FILE__));
            exit;
        } catch (PDOException $e) {
            $mensagem_feedback = "<div class='p-4 mb-4 text-sm text-red-700 bg-red-100 rounded-lg'>Erro ao apagar curso.</div>";
        }
    } elseif ($acao === 'editar' && $id_curso) {
        $mostrar_form_edicao = true;
        $stmt = $pdo->prepare("SELECT * FROM cursos WHERE id = ?");
        $stmt->execute([$id_curso]);
        $curso_atual = $stmt->fetch();
        if (!$curso_atual) {
            $_SESSION['mensagem_crud_curso'] = "<div class='p-4 mb-4 text-sm text-red-700 bg-red-100 rounded-lg'>Curso não encontrado.</div>";
            header('Location: ' . basename(__FILE__));
            exit;
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_curso = $_POST['id_curso'] ?? null;
    $titulo = trim($_POST['titulo'] ?? '');
    $preco = floatval($_POST['preco'] ?? 0);
    $nivel = trim($_POST['nivel'] ?? '');
    $ativo = isset($_POST['ativo']) ? 1 : 0;

    $erro = '';
    if (!$titulo) {
        $erro = "O título do curso é obrigatório.";
    } elseif ($preco < 0) {
        $erro = "O preço deve ser um valor válido.";
    }

    if ($erro) {
        $mensagem_feedback = "<div class='p-4 mb-4 text-sm text-red-700 bg-red-100 rounded-lg'>{$erro}</div>";
        $mostrar_form_edicao = true;
        $curso_atual = [
            'id' => $id_curso,
            'titulo' => $titulo,
            'preco' => $preco,
            'nivel' => $nivel,
            'ativo' => $ativo
        ];
    } else {
        try {
            if ($id_curso) {
                $stmt = $pdo->prepare("UPDATE cursos SET titulo = ?, preco = ?, nivel = ?, ativo = ? WHERE id = ?");
                $stmt->execute([$titulo, $preco, $nivel, $ativo, $id_curso]);
                $_SESSION['mensagem_crud_curso'] = "<div class='p-4 mb-4 text-sm text-green-700 bg-green-100 rounded-lg'>Curso atualizado com sucesso.</div>";
                header('Location: ' . basename(__FILE__));
                exit;
            } else {
                $mensagem_feedback = "<div class='p-4 mb-4 text-sm text-yellow-700 bg-yellow-100 rounded-lg'>Erro: ID do curso não especificado para atualização.</div>";
                $mostrar_form_edicao = true;
            }
        } catch (PDOException $e) {
            $mensagem_feedback = "<div class='p-4 mb-4 text-sm text-red-700 bg-red-100 rounded-lg'>Erro ao atualizar o curso: " . htmlspecialchars($e->getMessage()) . "</div>";
            $mostrar_form_edicao = true;
            $curso_atual = [
                'id' => $id_curso,
                'titulo' => $titulo,
                'preco' => $preco,
                'nivel' => $nivel,
                'ativo' => $ativo
            ];
        }
    }
}

if (!$mostrar_form_edicao) {
    try {
        $stmt = $pdo->query("SELECT id, titulo, preco, nivel, ativo FROM cursos ORDER BY titulo ASC");
        $meus_cursos = $stmt->fetchAll();
    } catch (PDOException $e) {
        error_log("Erro ao buscar os cursos: " . $e->getMessage());
        $mensagem_feedback = "<div class='p-4 mb-4 text-sm text-red-700 bg-red-100 rounded-lg'>Erro ao carregar os cursos.</div>";
        $meus_cursos = [];
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meus Cursos - ForensicX</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style> body { font-family: 'Montserrat', sans-serif; } </style>
</head>
<body class="bg-gray-100 flex flex-col min-h-screen">
    <?php include 'HeaderProfessor.php'; ?>

    <main class="flex-1 container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <?php if ($mostrar_form_edicao && $curso_atual): ?>
            <h1 class="text-3xl font-bold text-gray-800 mb-6">Editar Curso</h1>
            <?php if ($mensagem_feedback) echo $mensagem_feedback; ?>
            <form method="POST" class="max-w-lg bg-white p-6 rounded-xl shadow-md">
                <input type="hidden" name="id_curso" value="<?php echo htmlspecialchars($curso_atual['id']); ?>">
                <label class="block mb-4">
                    <span class="text-gray-700 font-semibold">Título do Curso</span>
                    <input type="text" name="titulo" value="<?php echo htmlspecialchars($curso_atual['titulo']); ?>" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-purple-500 focus:border-purple-500">
                </label>
                <label class="block mb-4">
                    <span class="text-gray-700 font-semibold">Preço (R$)</span>
                    <input type="number" step="0.01" min="0" name="preco" value="<?php echo htmlspecialchars($curso_atual['preco']); ?>" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-purple-500 focus:border-purple-500">
                </label>
                <label class="block mb-4">
                    <span class="text-gray-700 font-semibold">Nível</span>
                    <input type="text" name="nivel" value="<?php echo htmlspecialchars($curso_atual['nivel']); ?>" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-purple-500 focus:border-purple-500">
                </label>
                <label class="inline-flex items-center mb-6">
                    <input type="checkbox" name="ativo" value="1" <?php echo ($curso_atual['ativo'] ? 'checked' : ''); ?> class="form-checkbox text-purple-600">
                    <span class="ml-2 text-gray-700 font-semibold">Publicado</span>
                </label>
                <div class="flex gap-4">
                    <button type="submit" class="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition">Salvar</button>
                    <a href="<?php echo basename(__FILE__); ?>" class="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-100">Cancelar</a>
                </div>
            </form>
        <?php else: ?>
            <header class="flex flex-wrap justify-between items-center mb-8 gap-4">
                <div>
                    <h1 class="text-3xl font-bold text-gray-800">Todos os Cursos</h1>
                    <p class="text-gray-600">Veja a lista completa de cursos cadastrados na plataforma.</p>
                </div>
            </header>

            <?php if ($mensagem_feedback) echo $mensagem_feedback; ?>
            <?php if (isset($_SESSION['mensagem_crud_curso'])) {
                echo $_SESSION['mensagem_crud_curso'];
                unset($_SESSION['mensagem_crud_curso']);
            } ?>

            <div class="bg-white rounded-xl shadow-lg overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="min-w-full leading-normal">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Título</th>
                                <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Preço</th>
                                <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Nível</th>
                                <th class="px-6 py-4 text-center text-xs font-semibold text-gray-600 uppercase tracking-wider">Status</th>
                                <th class="px-6 py-4 text-right text-xs font-semibold text-gray-600 uppercase tracking-wider">Ações</th>
                            </tr>
                        </thead>
                        <tbody class="text-gray-700">
                            <?php if (empty($meus_cursos)): ?>
                                <tr><td colspan="5" class="text-center py-12 text-gray-500"><i class="fas fa-book-reader text-4xl mb-3"></i><p>Nenhum curso cadastrado ainda.</p></td></tr>
                            <?php else: ?>
                                <?php foreach ($meus_cursos as $curso): ?>
                                    <tr class="border-b hover:bg-gray-50">
                                        <td class="px-6 py-4"><?php echo htmlspecialchars($curso['titulo']); ?></td>
                                        <td class="px-6 py-4">R$ <?php echo number_format($curso['preco'], 2, ',', '.'); ?></td>
                                        <td class="px-6 py-4"><?php echo htmlspecialchars($curso['nivel']); ?></td>
                                        <td class="px-6 py-4 text-center">
                                            <span class="px-3 py-1 font-semibold rounded-full text-xs <?php echo $curso['ativo'] ? 'text-green-900 bg-green-200' : 'text-gray-700 bg-gray-200'; ?>">
                                                <?php echo $curso['ativo'] ? 'Publicado' : 'Rascunho'; ?>
                                            </span>
                                        </td>
                                        <td class="px-6 py-4 text-right">
                                            <a href="?acao=editar&id_curso=<?php echo $curso['id']; ?>" class="text-indigo-600 hover:text-indigo-900 mr-4">Editar</a>
                                            <a href="?acao=apagar&id_curso=<?php echo $curso['id']; ?>" onclick="return confirm('Tem certeza que deseja apagar este curso?');" class="text-red-600 hover:text-red-900">Apagar</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="mt-8 text-center">
                <a href="professor.php" class="text-purple-600 hover:text-purple-800 font-medium">&larr; Voltar para o Dashboard</a>
            </div>
        <?php endif; ?>
    </main>

    <?php include 'footer.php'; ?>
</body>
</html>
