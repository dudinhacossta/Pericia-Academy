<?php
session_start();
require_once 'config.php'; 

// Segurança: Garante que apenas professores logados podem aceder
if (!isset($_SESSION['client_id']) || !isset($_SESSION['client_type']) || $_SESSION['client_type'] !== 'professor') {
    header('Location: login.php?erro=acesso_negado');
    exit;
}

$id_professor_logado = $_SESSION['client_id'];
$nome_professor = $_SESSION['client_name'] ?? 'Professor(a)';

$mensagem_feedback = '';
$tipo_mensagem = '';

// --- LÓGICA PARA ATUALIZAR OS DADOS (quando o formulário é enviado) ---
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome_utilizador_novo = trim($_POST['nome_utilizador']);
    $email_novo = trim($_POST['email']);
    $telefone_novo = trim($_POST['telefone'] ?? '');
    $senha_atual_form = trim($_POST['senha_atual'] ?? '');
    $nova_senha_form = trim($_POST['nova_senha'] ?? '');
    $confirmar_nova_senha_form = trim($_POST['confirmar_nova_senha'] ?? '');

    $erros = [];
    
    // Busca a senha atual para verificação
    $stmt_pass = $pdo->prepare("SELECT senha FROM clientes WHERE id = :id_cliente");
    $stmt_pass->execute([':id_cliente' => $id_professor_logado]);
    $senha_atual_hash = $stmt_pass->fetchColumn();

    // Validações
    if (empty($nome_utilizador_novo) || empty($email_novo)) {
        $erros[] = "Nome de utilizador e email são obrigatórios.";
    }

    $precisa_senha_atual = !empty($nova_senha_form) || ($email_novo !== $_SESSION['client_email']);

    if ($precisa_senha_atual) {
        if (empty($senha_atual_form)) {
            $erros[] = "Para alterar email ou senha, a sua senha atual é necessária.";
        } elseif (!password_verify($senha_atual_form, $senha_atual_hash)) {
            $erros[] = "A senha atual fornecida está incorreta.";
        }
    }
    
    if (!empty($nova_senha_form)) {
        if (strlen($nova_senha_form) < 6) {
            $erros[] = "A nova senha deve ter pelo menos 6 caracteres.";
        }
        if ($nova_senha_form !== $confirmar_nova_senha_form) {
            $erros[] = "A nova senha e a confirmação não coincidem.";
        }
    }
    
    // Se não houver erros, prossiga com a atualização
    if (empty($erros)) {
        try {
            $campos_para_atualizar = [];
            $params_para_atualizar = [':id_cliente' => $id_professor_logado];

            // Adiciona campos ao update apenas se eles foram realmente alterados
            if ($nome_utilizador_novo !== $_SESSION['client_name']) {
                $campos_para_atualizar['nome_utilizador'] = $nome_utilizador_novo;
            }
            if ($email_novo !== $_SESSION['client_email']) {
                $campos_para_atualizar['email'] = $email_novo;
            }
            // A lógica para telefone pode ser mais simples, apenas atualiza
            $campos_para_atualizar['telefone'] = !empty($telefone_novo) ? $telefone_novo : null;

            if (!empty($nova_senha_form)) {
                $campos_para_atualizar['senha'] = password_hash($nova_senha_form, PASSWORD_DEFAULT);
            }
            
            if (!empty($campos_para_atualizar)) {
                $sql_parts = [];
                foreach ($campos_para_atualizar as $key => $value) {
                    $sql_parts[] = "{$key} = :{$key}";
                    $params_para_atualizar[":{$key}"] = $value;
                }
                
                $sql = "UPDATE clientes SET " . implode(', ', $sql_parts) . " WHERE id = :id_cliente";
                
                $stmt = $pdo->prepare($sql);
                $stmt->execute($params_para_atualizar);
                
                // Atualiza os dados da sessão
                $_SESSION['client_name'] = $nome_utilizador_novo;
                $_SESSION['client_email'] = $email_novo;

                $mensagem_feedback = "Informações atualizadas com sucesso!";
                $tipo_mensagem = 'sucesso';
            } else {
                $mensagem_feedback = "Nenhuma alteração foi feita.";
                $tipo_mensagem = 'info';
            }

        } catch (PDOException $e) {
            error_log("Erro ao atualizar conta: " . $e->getMessage());
            $mensagem_feedback = "Erro ao salvar as alterações. Verifique se o novo nome de utilizador ou email já não estão em uso.";
            $tipo_mensagem = 'erro';
        }
    } else {
        $mensagem_feedback = implode("<br>", $erros);
        $tipo_mensagem = 'erro';
    }
}

// Busca os dados mais recentes do professor para exibir no formulário
try {
    $stmt = $pdo->prepare("SELECT nome_utilizador, email, telefone FROM clientes WHERE id = :id");
    $stmt->execute([':id' => $id_professor_logado]);
    $professor_info = $stmt->fetch();
} catch(PDOException $e) {
    $professor_info = null;
    $mensagem_feedback = "Não foi possível carregar os seus dados.";
    $tipo_mensagem = 'erro';
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configurações - Painel do Professor</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style> 
        body { font-family: 'Montserrat', sans-serif; } 
    </style>
</head>
<body class="bg-gray-200 flex flex-col min-h-screen">
    <?php include 'header.php'; ?>

    <!-- Main Content -->
    <main class="flex-1 container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div class="max-w-2xl mx-auto">
            <header class="text-center mb-8">
                <h1 class="text-3xl font-bold text-gray-800">Configurações da Conta</h1>
                <p class="text-gray-600 mt-2">Atualize suas informações de perfil e segurança.</p>
            </header>
            
            <?php if ($mensagem_feedback): ?>
                <div class="p-4 mb-6 text-sm rounded-lg <?php echo $tipo_mensagem === 'sucesso' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'; ?>">
                    <?php echo $mensagem_feedback; ?>
                </div>
            <?php endif; ?>

            <?php if ($professor_info): ?>
            <div class="bg-white p-8 rounded-xl shadow-lg">
                <form action="configuracoes.php" method="POST" class="space-y-6">
                    <div>
                        <label for="nome_utilizador" class="block text-sm font-medium text-gray-700 mb-1">Nome de Utilizador</label>
                        <input type="text" id="nome_utilizador" name="nome_utilizador" value="<?php echo htmlspecialchars($professor_info['nome_utilizador']); ?>" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-600" required>
                    </div>
                    <div>
                        <label for="email" class="block text-sm font-medium text-gray-700 mb-1">Email</label>
                        <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($professor_info['email']); ?>" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-600" required>
                    </div>
                    <div>
                        <label for="telefone" class="block text-sm font-medium text-gray-700 mb-1">Telefone (Opcional)</label>
                        <input type="tel" id="telefone" name="telefone" value="<?php echo htmlspecialchars($professor_info['telefone'] ?? ''); ?>" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-600">
                    </div>

                    <hr class="my-6 border-gray-200">
                    <p class="text-sm text-gray-500">Para alterar seu email ou senha, por favor, insira sua senha atual. Deixe os campos de nova senha em branco se não desejar alterá-la.</p>
                    
                    <div>
                        <label for="senha_atual" class="block text-sm font-medium text-gray-700 mb-1">Sua Senha Atual</label>
                        <input type="password" id="senha_atual" name="senha_atual" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-600" autocomplete="current-password">
                    </div>
                    <div>
                        <label for="nova_senha" class="block text-sm font-medium text-gray-700 mb-1">Nova Senha</label>
                        <input type="password" id="nova_senha" name="nova_senha" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-600" autocomplete="new-password">
                    </div>
                    <div>
                        <label for="confirmar_nova_senha" class="block text-sm font-medium text-gray-700 mb-1">Confirmar Nova Senha</label>
                        <input type="password" id="confirmar_nova_senha" name="confirmar_nova_senha" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-600" autocomplete="new-password">
                    </div>

                    <div class="flex justify-end pt-4 gap-4">
                        <a href="professor.php" class="bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-3 px-6 rounded-lg transition duration-300">
                           Voltar ao Painel
                        </a>
                        <button type="submit" class="bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 px-6 rounded-lg transition duration-300">
                            Salvar Alterações
                        </button>
                    </div>
                </form>
            </div>
            <?php endif; ?>
        </div>
    </main>

    <?php include 'footer.php'; ?>
</body>
</html>
