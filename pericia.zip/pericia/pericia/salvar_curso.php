<?php
session_start();
require_once '../config.php';

// Verificação de segurança: só processa se for um POST e se o utilizador for professor
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_SESSION['client_id']) || !isset($_SESSION['client_type']) || $_SESSION['client_type'] !== 'professor') {
    header('Location: ../login.php');
    exit;
}

$id_professor_logado = $_SESSION['client_id'];

// Coleta de dados básicos do curso
$titulo = trim($_POST['titulo'] ?? '');
$subtitulo = trim($_POST['subtitulo'] ?? '');
$preco = filter_var(str_replace(',', '.', trim($_POST['preco'] ?? '')), FILTER_VALIDATE_FLOAT);
$nivel = $_POST['nivel'] ?? 'Iniciante';
$duracao_horas = filter_var($_POST['duracao_horas'], FILTER_VALIDATE_INT);
$descricao_completa = trim($_POST['descricao_completa'] ?? '');
$ativo = isset($_POST['ativo']) ? 1 : 0;
$url_imagem_capa = trim($_POST['url_imagem_capa'] ?? '');
$video_promocional_url = trim($_POST['video_promocional_url'] ?? '');

// Módulos e Aulas vêm como arrays
$modulos = $_POST['modulos'] ?? [];

// Validação simples
if (empty($titulo) || $preco === false || $duracao_horas === false) {
    $_SESSION['mensagem_crud_curso'] = "<div class='p-4 mb-4 text-sm text-red-700 bg-red-100 rounded-lg'>Erro: Título, preço e duração são obrigatórios.</div>";
    header('Location: ../professor_painel.php?secao=novo_curso');
    exit;
}

$pdo->beginTransaction();
try {
    // Insere o curso principal na tabela 'cursos'
    $stmt_curso = $pdo->prepare(
        "INSERT INTO cursos (titulo, subtitulo, instrutor, id_instrutor, preco, nivel, duracao_horas, descricao_completa, ativo, url_imagem_capa, video_promocional_url) 
         VALUES (:titulo, :subtitulo, :instrutor, :id_instrutor, :preco, :nivel, :duracao_horas, :descricao, :ativo, :url_imagem, :video_url)"
    );
    $stmt_curso->execute([
        ':titulo' => $titulo,
        ':subtitulo' => $subtitulo,
        ':instrutor' => $_SESSION['client_name'], // Pega o nome do professor da sessão
        ':id_instrutor' => $id_professor_logado,
        ':preco' => $preco,
        ':nivel' => $nivel,
        ':duracao_horas' => $duracao_horas,
        ':descricao' => $descricao_completa,
        ':ativo' => $ativo,
        ':url_imagem' => $url_imagem_capa,
        ':video_url' => $video_promocional_url
    ]);
    $id_novo_curso = $pdo->lastInsertId();

    // Loop para inserir os módulos e suas aulas
    foreach ($modulos as $ordem_modulo => $modulo_data) {
        if (!empty($modulo_data['titulo'])) {
            $stmt_modulo = $pdo->prepare(
                "INSERT INTO modulos (id_curso, titulo_modulo, ordem_modulo) VALUES (:id_curso, :titulo_modulo, :ordem_modulo)"
            );
            $stmt_modulo->execute([
                ':id_curso' => $id_novo_curso,
                ':titulo_modulo' => $modulo_data['titulo'],
                ':ordem_modulo' => $ordem_modulo + 1
            ]);
            $id_novo_modulo = $pdo->lastInsertId();

            // Loop para inserir as aulas deste módulo
            if (isset($modulo_data['aulas']) && is_array($modulo_data['aulas'])) {
                foreach ($modulo_data['aulas'] as $ordem_aula => $aula_data) {
                    if (!empty($aula_data['titulo']) && !empty($aula_data['conteudo'])) {
                        $stmt_aula = $pdo->prepare(
                            "INSERT INTO aulas (id_modulo, titulo_aula, tipo_conteudo, conteudo_url, ordem_aula) 
                             VALUES (:id_modulo, :titulo_aula, :tipo_conteudo, :conteudo_url, :ordem_aula)"
                        );
                        $stmt_aula->execute([
                            ':id_modulo' => $id_novo_modulo,
                            ':titulo_aula' => $aula_data['titulo'],
                            ':tipo_conteudo' => $aula_data['tipo'],
                            ':conteudo_url' => $aula_data['conteudo'],
                            ':ordem_aula' => $ordem_aula + 1
                        ]);
                    }
                }
            }
        }
    }
    
    $pdo->commit(); // Se tudo deu certo, confirma as alterações
    $_SESSION['mensagem_crud_curso'] = "<div class='p-4 mb-4 text-sm text-green-700 bg-green-100 rounded-lg'>Curso salvo com sucesso!</div>";

} catch (PDOException $e) {
    $pdo->rollBack(); // Se algo deu errado, desfaz tudo
    error_log("Erro ao salvar curso: " . $e->getMessage());
    $_SESSION['mensagem_crud_curso'] = "<div class='p-4 mb-4 text-sm text-red-700 bg-red-100 rounded-lg'>Erro ao salvar o curso. Detalhes: " . htmlspecialchars($e->getMessage()) . "</div>";
}

// Redireciona de volta para a lista de cursos do professor ou painel
header('Location: ../professor_painel.php?secao=meus_cursos');
exit;
?>
